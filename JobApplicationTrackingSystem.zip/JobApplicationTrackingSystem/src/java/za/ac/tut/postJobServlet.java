/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut;

import jakarta.ejb.EJB;
import java.io.IOException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.JobFacadeLocal;
import za.ac.tut.entities.Applicant;
import za.ac.tut.entities.Job;

/**
 *
 * @author maton
 */
public class postJobServlet extends HttpServlet {
    
    @EJB
    private JobFacadeLocal jfl;
   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Long id = Long.valueOf(request.getParameter("id"));
        String compName = request.getParameter("companyName");
        String desc = request.getParameter("description");
        String requirements = request.getParameter("requirements");
        
        Job j =  createA(id, compName, desc, requirements);
        jfl.create(j);
        
        RequestDispatcher disp = request.getRequestDispatcher("postJobOutcome.jsp");
        disp.forward(request, response);
        
    }
    
    private Job createA(Long id,String compName,String desc,String requirements){
        
        Job a = new Job();
        a.setId(id);
        a.setCompName(compName);
        a.setDescription(desc);
        a.setRequirement(requirements);
        
        return a;
    }

    
}
