/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut;

import jakarta.ejb.EJB;
import java.io.IOException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.List;
import za.ac.tut.ejb.bl.ApplicantFacadeLocal;
import za.ac.tut.entities.Applicant;

/**
 *
 * @author maton
 */
@MultipartConfig
public class jobApplyServlet extends HttpServlet {

    @EJB
    private ApplicantFacadeLocal afl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    
        Long id = Long.valueOf(request.getParameter("id"));
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        String email = request.getParameter("email");
        Part file = request.getPart("cv");
        InputStream inputStream = file.getInputStream();
        byte[] cv = convertToBytes(inputStream);
        String status = request.getParameter("status");
        Long Jid = Long.valueOf(request.getParameter("Jid"));
        
        Applicant a =  createA(id, name, surname, email, cv, status,Jid);
        afl.create(a);
        
        RequestDispatcher disp = request.getRequestDispatcher("jobApplyOutcome.jsp");
        disp.forward(request, response);
    }
     private byte[] convertToBytes( InputStream inputStream) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        int bytesRead;
        byte[] data = new byte[1024];
        while ((bytesRead = inputStream.read(data, 0, data.length)) != -1) {
            buffer.write(data, 0, bytesRead);
        }
        return buffer.toByteArray();

    }
     private Applicant createA( Long id,String name,String surname,String email,byte[] cv,String status, Long Jid){
         
         Applicant a = new Applicant();
         a.setId(id);
         a.setName(name);
         a.setSurname(surname);
         a.setEmail(email);
         a.setCv(cv);
         a.setjId(Jid);
         a.setStatus(status);
         a.setDate(new Date());
         return a;
     }
   
}
