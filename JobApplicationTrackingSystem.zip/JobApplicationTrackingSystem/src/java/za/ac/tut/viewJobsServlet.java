/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut;

import jakarta.ejb.EJB;
import java.io.IOException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;
import za.ac.tut.ejb.bl.JobFacadeLocal;
import za.ac.tut.entities.Job;

/**
 *
 * @author maton
 */
public class viewJobsServlet extends HttpServlet {

    @EJB
    private JobFacadeLocal jfl;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        
        List<Job> job = jfl.findAll();
        
        request.setAttribute("jobs", job);
        
        RequestDispatcher disp = request.getRequestDispatcher("viewJobsOutcome.jsp");
        disp.forward(request, response);
    }

    

}
