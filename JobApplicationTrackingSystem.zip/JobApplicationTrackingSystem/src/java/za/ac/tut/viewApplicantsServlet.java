/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut;

import jakarta.ejb.EJB;
import java.io.IOException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import za.ac.tut.ejb.bl.ApplicantFacadeLocal;
import za.ac.tut.entities.Applicant;

/**
 *
 * @author maton
 */
public class viewApplicantsServlet extends HttpServlet {

    @EJB
    private ApplicantFacadeLocal afl;
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
       
       List< Applicant> applicant = afl.findAll();
        
        
        request.setAttribute("applicant", applicant);
        
        RequestDispatcher disp = request.getRequestDispatcher("viewApplicantOutcome.jsp");
        disp.forward(request, response);
    }

   

}
